
# Book

## Structure

`Book`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ageGroup` | `string \| undefined` | Optional | - |
| `author` | `string \| undefined` | Optional | - |
| `contributor` | `string \| undefined` | Optional | - |
| `contributorNote` | `string \| undefined` | Optional | - |
| `createdDate` | `string \| undefined` | Optional | - |
| `description` | `string \| undefined` | Optional | - |
| `price` | `number \| undefined` | Optional | - |
| `primaryIsbn13` | `string \| undefined` | Optional | - |
| `primaryIsbn10` | `string \| undefined` | Optional | - |
| `publisher` | `string \| undefined` | Optional | - |
| `rank` | `number \| undefined` | Optional | - |
| `title` | `string \| undefined` | Optional | - |
| `updatedDate` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "age_group": null,
  "author": null,
  "contributor": null,
  "contributor_note": null,
  "created_date": null,
  "description": null,
  "price": null,
  "primary_isbn13": null,
  "primary_isbn10": null,
  "publisher": null,
  "rank": null,
  "title": null,
  "updated_date": null
}
```

