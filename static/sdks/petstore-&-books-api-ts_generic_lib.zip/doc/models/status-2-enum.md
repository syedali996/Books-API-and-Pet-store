
# Status 2 Enum

## Enumeration

`Status2Enum`

## Fields

| Name |
|  --- |
| `available` |
| `pending` |
| `sold` |

