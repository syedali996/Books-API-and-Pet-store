
# GET Lists Names Format Response

## Structure

`GETListsNamesFormatResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string \| undefined` | Optional | - |
| `copyright` | `string \| undefined` | Optional | - |
| `numResults` | `number \| undefined` | Optional | - |
| `results` | [`Results3[] \| undefined`](../../doc/models/results-3.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

