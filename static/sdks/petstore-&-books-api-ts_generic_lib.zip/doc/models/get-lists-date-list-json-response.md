
# GET Lists Date List Json Response

## Structure

`GETListsDateListJsonResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string \| undefined` | Optional | - |
| `copyright` | `string \| undefined` | Optional | - |
| `numResults` | `number \| undefined` | Optional | - |
| `lastModified` | `string \| undefined` | Optional | - |
| `results` | [`Results2 \| undefined`](../../doc/models/results-2.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "last_modified": null,
  "results": null
}
```

