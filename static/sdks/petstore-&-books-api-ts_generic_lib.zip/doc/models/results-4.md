
# Results 4

## Structure

`Results4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `title` | `string \| undefined` | Optional | - |
| `description` | `string \| undefined` | Optional | - |
| `contributor` | `string \| undefined` | Optional | - |
| `author` | `string \| undefined` | Optional | - |
| `contributorNote` | `string \| undefined` | Optional | - |
| `price` | `number \| undefined` | Optional | - |
| `ageGroup` | `string \| undefined` | Optional | - |
| `publisher` | `string \| undefined` | Optional | - |
| `isbns` | [`Isbn[] \| undefined`](../../doc/models/isbn.md) | Optional | - |
| `ranksHistory` | [`RanksHistory[] \| undefined`](../../doc/models/ranks-history.md) | Optional | - |
| `reviews` | [`Review[] \| undefined`](../../doc/models/review.md) | Optional | - |

## Example (as JSON)

```json
{
  "title": null,
  "description": null,
  "contributor": null,
  "author": null,
  "contributor_note": null,
  "price": null,
  "age_group": null,
  "publisher": null,
  "isbns": null,
  "ranks_history": null,
  "reviews": null
}
```

