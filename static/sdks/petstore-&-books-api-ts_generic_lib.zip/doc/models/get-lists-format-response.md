
# GET Lists Format Response

## Structure

`GETListsFormatResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string \| undefined` | Optional | - |
| `copyright` | `string \| undefined` | Optional | - |
| `numResults` | `number \| undefined` | Optional | - |
| `lastModified` | `string \| undefined` | Optional | - |
| `results` | [`Results1[] \| undefined`](../../doc/models/results-1.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "last_modified": null,
  "results": null
}
```

