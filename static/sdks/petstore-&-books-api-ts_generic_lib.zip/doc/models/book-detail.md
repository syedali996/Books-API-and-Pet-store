
# Book Detail

## Structure

`BookDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `title` | `string \| undefined` | Optional | - |
| `description` | `string \| undefined` | Optional | - |
| `contributor` | `string \| undefined` | Optional | - |
| `author` | `string \| undefined` | Optional | - |
| `contributorNote` | `string \| undefined` | Optional | - |
| `price` | `number \| undefined` | Optional | - |
| `ageGroup` | `string \| undefined` | Optional | - |
| `publisher` | `string \| undefined` | Optional | - |
| `primaryIsbn13` | `string \| undefined` | Optional | - |
| `primaryIsbn10` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "title": null,
  "description": null,
  "contributor": null,
  "author": null,
  "contributor_note": null,
  "price": null,
  "age_group": null,
  "publisher": null,
  "primary_isbn13": null,
  "primary_isbn10": null
}
```

