
# Results 5

## Structure

`Results5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `url` | `string \| undefined` | Optional | - |
| `publicationDt` | `string \| undefined` | Optional | - |
| `byline` | `string \| undefined` | Optional | - |
| `bookTitle` | `string \| undefined` | Optional | - |
| `bookAuthor` | `string \| undefined` | Optional | - |
| `summary` | `string \| undefined` | Optional | - |
| `isbn13` | `string[] \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "url": null,
  "publication_dt": null,
  "byline": null,
  "book_title": null,
  "book_author": null,
  "summary": null,
  "isbn13": null
}
```

