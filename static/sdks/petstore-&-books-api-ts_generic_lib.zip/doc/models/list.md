
# List

## Structure

`List`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listId` | `number \| undefined` | Optional | - |
| `listName` | `string \| undefined` | Optional | - |
| `displayName` | `string \| undefined` | Optional | - |
| `updated` | `string \| undefined` | Optional | - |
| `listImage` | `string \| undefined` | Optional | - |
| `books` | [`Book[] \| undefined`](../../doc/models/book.md) | Optional | - |

## Example (as JSON)

```json
{
  "list_id": null,
  "list_name": null,
  "display_name": null,
  "updated": null,
  "list_image": null,
  "books": null
}
```

