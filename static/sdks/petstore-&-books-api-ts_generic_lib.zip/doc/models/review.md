
# Review

## Structure

`Review`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bookReviewLink` | `string \| undefined` | Optional | - |
| `firstChapterLink` | `string \| undefined` | Optional | - |
| `sundayReviewLink` | `string \| undefined` | Optional | - |
| `articleChapterLink` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "book_review_link": null,
  "first_chapter_link": null,
  "sunday_review_link": null,
  "article_chapter_link": null
}
```

