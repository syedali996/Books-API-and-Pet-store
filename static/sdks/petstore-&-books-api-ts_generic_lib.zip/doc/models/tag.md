
# Tag

## Structure

`Tag`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `bigint \| undefined` | Optional | - |
| `name` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "name": null
}
```

