
# Isbn

## Structure

`Isbn`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `isbn10` | `string \| undefined` | Optional | - |
| `isbn13` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "isbn10": null,
  "isbn13": null
}
```

