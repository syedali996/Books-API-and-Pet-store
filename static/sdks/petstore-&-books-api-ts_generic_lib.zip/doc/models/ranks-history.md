
# Ranks History

## Structure

`RanksHistory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `primaryIsbn10` | `string \| undefined` | Optional | - |
| `primaryIsbn13` | `string \| undefined` | Optional | - |
| `rank` | `number \| undefined` | Optional | - |
| `listName` | `string \| undefined` | Optional | - |
| `displayName` | `string \| undefined` | Optional | - |
| `publishedDate` | `string \| undefined` | Optional | - |
| `bestsellersDate` | `string \| undefined` | Optional | - |
| `weeksOnList` | `number \| undefined` | Optional | - |
| `ranksLastWeek` | `string \| undefined` | Optional | - |
| `asterisk` | `number \| undefined` | Optional | - |
| `dagger` | `number \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "primary_isbn10": null,
  "primary_isbn13": null,
  "rank": null,
  "list_name": null,
  "display_name": null,
  "published_date": null,
  "bestsellers_date": null,
  "weeks_on_list": null,
  "ranks_last_week": null,
  "asterisk": null,
  "dagger": null
}
```

