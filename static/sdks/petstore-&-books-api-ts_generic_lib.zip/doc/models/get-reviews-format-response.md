
# GET Reviews Format Response

## Structure

`GETReviewsFormatResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string \| undefined` | Optional | - |
| `copyright` | `string \| undefined` | Optional | - |
| `numResults` | `number \| undefined` | Optional | - |
| `results` | [`Results5[] \| undefined`](../../doc/models/results-5.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

