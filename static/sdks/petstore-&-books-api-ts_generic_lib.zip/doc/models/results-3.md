
# Results 3

## Structure

`Results3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listName` | `string \| undefined` | Optional | - |
| `displayName` | `string \| undefined` | Optional | - |
| `listNameEncoded` | `string \| undefined` | Optional | - |
| `oldestPublishedDate` | `string \| undefined` | Optional | - |
| `newestPublishedDate` | `string \| undefined` | Optional | - |
| `updated` | [`UpdatedEnum \| undefined`](../../doc/models/updated-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "list_name": null,
  "display_name": null,
  "list_name_encoded": null,
  "oldest_published_date": null,
  "newest_published_date": null,
  "updated": null
}
```

