
# Book 1

## Structure

`Book1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rank` | `number \| undefined` | Optional | - |
| `rankLastWeek` | `number \| undefined` | Optional | - |
| `weeksOnList` | `number \| undefined` | Optional | - |
| `asterisk` | `number \| undefined` | Optional | - |
| `dagger` | `number \| undefined` | Optional | - |
| `primaryIsbn10` | `string \| undefined` | Optional | - |
| `primaryIsbn13` | `string \| undefined` | Optional | - |
| `publisher` | `string \| undefined` | Optional | - |
| `description` | `string \| undefined` | Optional | - |
| `price` | `number \| undefined` | Optional | - |
| `title` | `string \| undefined` | Optional | - |
| `author` | `string \| undefined` | Optional | - |
| `contributor` | `string \| undefined` | Optional | - |
| `contributorNote` | `string \| undefined` | Optional | - |
| `bookImage` | `string \| undefined` | Optional | - |
| `amazonProductUrl` | `string \| undefined` | Optional | - |
| `ageGroup` | `string \| undefined` | Optional | - |
| `bookReviewLink` | `string \| undefined` | Optional | - |
| `firstChapterLink` | `string \| undefined` | Optional | - |
| `sundayReviewLink` | `string \| undefined` | Optional | - |
| `articleChapterLink` | `string \| undefined` | Optional | - |
| `isbns` | [`Isbn[] \| undefined`](../../doc/models/isbn.md) | Optional | - |

## Example (as JSON)

```json
{
  "rank": null,
  "rank_last_week": null,
  "weeks_on_list": null,
  "asterisk": null,
  "dagger": null,
  "primary_isbn10": null,
  "primary_isbn13": null,
  "publisher": null,
  "description": null,
  "price": null,
  "title": null,
  "author": null,
  "contributor": null,
  "contributor_note": null,
  "book_image": null,
  "amazon_product_url": null,
  "age_group": null,
  "book_review_link": null,
  "first_chapter_link": null,
  "sunday_review_link": null,
  "article_chapter_link": null,
  "isbns": null
}
```

