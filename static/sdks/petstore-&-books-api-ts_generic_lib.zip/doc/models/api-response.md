
# Api Response

## Structure

`ApiResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `number \| undefined` | Optional | - |
| `type` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "code": null,
  "type": null,
  "message": null
}
```

