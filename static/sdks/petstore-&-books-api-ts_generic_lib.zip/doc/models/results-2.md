
# Results 2

## Structure

`Results2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `listName` | `string \| undefined` | Optional | - |
| `bestsellersDate` | `string \| undefined` | Optional | - |
| `publishedDate` | `string \| undefined` | Optional | - |
| `displayName` | `string \| undefined` | Optional | - |
| `normalListEndsAt` | `number \| undefined` | Optional | - |
| `updated` | `string \| undefined` | Optional | - |
| `books` | [`Book1[] \| undefined`](../../doc/models/book-1.md) | Optional | - |
| `corrections` | `unknown[] \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "list_name": null,
  "bestsellers_date": null,
  "published_date": null,
  "display_name": null,
  "normal_list_ends_at": null,
  "updated": null,
  "books": null,
  "corrections": null
}
```

