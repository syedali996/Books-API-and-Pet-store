
# Updated Enum

## Enumeration

`UpdatedEnum`

## Fields

| Name |
|  --- |
| `wEEKLY` |
| `mONTHLY` |

