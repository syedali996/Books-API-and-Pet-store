
# Results

## Structure

`Results`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bestsellersDate` | `string \| undefined` | Optional | - |
| `publishedDate` | `string \| undefined` | Optional | - |
| `lists` | [`List[] \| undefined`](../../doc/models/list.md) | Optional | - |

## Example (as JSON)

```json
{
  "bestsellers_date": null,
  "published_date": null,
  "lists": null
}
```

