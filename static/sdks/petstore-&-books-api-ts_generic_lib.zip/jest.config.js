module.exports = {
    testEnvironment: 'node',
    globals: {
        "__DEV__": true,
    }
};