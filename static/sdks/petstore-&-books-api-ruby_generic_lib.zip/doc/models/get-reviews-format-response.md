
# GET Reviews Format Response

## Structure

`GETReviewsFormatResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `String` | Optional | - |
| `copyright` | `String` | Optional | - |
| `num_results` | `Integer` | Optional | - |
| `results` | [`Array<Results5>`](../../doc/models/results-5.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

