
# List

## Structure

`List`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `list_id` | `Integer` | Optional | - |
| `list_name` | `String` | Optional | - |
| `display_name` | `String` | Optional | - |
| `updated` | `String` | Optional | - |
| `list_image` | `String` | Optional | - |
| `books` | [`Array<Book>`](../../doc/models/book.md) | Optional | - |

## Example (as JSON)

```json
{
  "list_id": null,
  "list_name": null,
  "display_name": null,
  "updated": null,
  "list_image": null,
  "books": null
}
```

