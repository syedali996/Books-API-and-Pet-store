
# Book Detail

## Structure

`BookDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `title` | `String` | Optional | - |
| `description` | `String` | Optional | - |
| `contributor` | `String` | Optional | - |
| `author` | `String` | Optional | - |
| `contributor_note` | `String` | Optional | - |
| `price` | `Integer` | Optional | - |
| `age_group` | `String` | Optional | - |
| `publisher` | `String` | Optional | - |
| `primary_isbn_13` | `String` | Optional | - |
| `primary_isbn_10` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "title": null,
  "description": null,
  "contributor": null,
  "author": null,
  "contributor_note": null,
  "price": null,
  "age_group": null,
  "publisher": null,
  "primary_isbn13": null,
  "primary_isbn10": null
}
```

