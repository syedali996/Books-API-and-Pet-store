
# Results 1

## Structure

`Results1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `list_name` | `String` | Optional | - |
| `display_name` | `String` | Optional | - |
| `bestsellers_date` | `String` | Optional | - |
| `published_date` | `String` | Optional | - |
| `rank` | `Integer` | Optional | - |
| `rank_last_week` | `Integer` | Optional | - |
| `weeks_on_list` | `Integer` | Optional | - |
| `asterisk` | `Integer` | Optional | - |
| `dagger` | `Integer` | Optional | - |
| `amazon_product_url` | `String` | Optional | - |
| `isbns` | [`Array<Isbn>`](../../doc/models/isbn.md) | Optional | - |
| `book_details` | [`Array<BookDetail>`](../../doc/models/book-detail.md) | Optional | - |
| `reviews` | [`Array<Review>`](../../doc/models/review.md) | Optional | - |

## Example (as JSON)

```json
{
  "list_name": null,
  "display_name": null,
  "bestsellers_date": null,
  "published_date": null,
  "rank": null,
  "rank_last_week": null,
  "weeks_on_list": null,
  "asterisk": null,
  "dagger": null,
  "amazon_product_url": null,
  "isbns": null,
  "book_details": null,
  "reviews": null
}
```

