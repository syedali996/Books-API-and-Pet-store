
# Status Enum

pet status in the store

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `PENDING` |
| `SOLD` |

