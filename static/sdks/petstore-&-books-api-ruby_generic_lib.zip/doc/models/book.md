
# Book

## Structure

`Book`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `age_group` | `String` | Optional | - |
| `author` | `String` | Optional | - |
| `contributor` | `String` | Optional | - |
| `contributor_note` | `String` | Optional | - |
| `created_date` | `String` | Optional | - |
| `description` | `String` | Optional | - |
| `price` | `Integer` | Optional | - |
| `primary_isbn_13` | `String` | Optional | - |
| `primary_isbn_10` | `String` | Optional | - |
| `publisher` | `String` | Optional | - |
| `rank` | `Integer` | Optional | - |
| `title` | `String` | Optional | - |
| `updated_date` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "age_group": null,
  "author": null,
  "contributor": null,
  "contributor_note": null,
  "created_date": null,
  "description": null,
  "price": null,
  "primary_isbn13": null,
  "primary_isbn10": null,
  "publisher": null,
  "rank": null,
  "title": null,
  "updated_date": null
}
```

