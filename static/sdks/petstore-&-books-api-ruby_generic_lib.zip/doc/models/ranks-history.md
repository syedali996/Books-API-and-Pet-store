
# Ranks History

## Structure

`RanksHistory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `primary_isbn_10` | `String` | Optional | - |
| `primary_isbn_13` | `String` | Optional | - |
| `rank` | `Integer` | Optional | - |
| `list_name` | `String` | Optional | - |
| `display_name` | `String` | Optional | - |
| `published_date` | `String` | Optional | - |
| `bestsellers_date` | `String` | Optional | - |
| `weeks_on_list` | `Integer` | Optional | - |
| `ranks_last_week` | `String` | Optional | - |
| `asterisk` | `Integer` | Optional | - |
| `dagger` | `Integer` | Optional | - |

## Example (as JSON)

```json
{
  "primary_isbn10": null,
  "primary_isbn13": null,
  "rank": null,
  "list_name": null,
  "display_name": null,
  "published_date": null,
  "bestsellers_date": null,
  "weeks_on_list": null,
  "ranks_last_week": null,
  "asterisk": null,
  "dagger": null
}
```

