
# GET Lists Format Response

## Structure

`GETListsFormatResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `String` | Optional | - |
| `copyright` | `String` | Optional | - |
| `num_results` | `Integer` | Optional | - |
| `last_modified` | `String` | Optional | - |
| `results` | [`Array<Results1>`](../../doc/models/results-1.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "last_modified": null,
  "results": null
}
```

