
# Overview Response

## Structure

`OverviewResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `String` | Optional | - |
| `copyright` | `String` | Optional | - |
| `num_results` | `Integer` | Optional | - |
| `results` | [`Results`](../../doc/models/results.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

