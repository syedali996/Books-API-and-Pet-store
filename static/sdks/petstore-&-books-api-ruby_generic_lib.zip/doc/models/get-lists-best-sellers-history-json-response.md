
# GET Lists Best Sellers History Json Response

## Structure

`GETListsBestSellersHistoryJsonResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `String` | Optional | - |
| `copyright` | `String` | Optional | - |
| `num_results` | `Integer` | Optional | - |
| `results` | [`Array<Results4>`](../../doc/models/results-4.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

