
# Results 5

## Structure

`Results5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `url` | `String` | Optional | - |
| `publication_dt` | `String` | Optional | - |
| `byline` | `String` | Optional | - |
| `book_title` | `String` | Optional | - |
| `book_author` | `String` | Optional | - |
| `summary` | `String` | Optional | - |
| `isbn_13` | `Array<String>` | Optional | - |

## Example (as JSON)

```json
{
  "url": null,
  "publication_dt": null,
  "byline": null,
  "book_title": null,
  "book_author": null,
  "summary": null,
  "isbn13": null
}
```

