
# Results

## Structure

`Results`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bestsellers_date` | `String` | Optional | - |
| `published_date` | `String` | Optional | - |
| `lists` | [`Array<List>`](../../doc/models/list.md) | Optional | - |

## Example (as JSON)

```json
{
  "bestsellers_date": null,
  "published_date": null,
  "lists": null
}
```

