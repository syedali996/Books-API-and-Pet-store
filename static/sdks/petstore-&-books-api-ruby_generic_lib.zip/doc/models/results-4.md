
# Results 4

## Structure

`Results4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `title` | `String` | Optional | - |
| `description` | `String` | Optional | - |
| `contributor` | `String` | Optional | - |
| `author` | `String` | Optional | - |
| `contributor_note` | `String` | Optional | - |
| `price` | `Integer` | Optional | - |
| `age_group` | `String` | Optional | - |
| `publisher` | `String` | Optional | - |
| `isbns` | [`Array<Isbn>`](../../doc/models/isbn.md) | Optional | - |
| `ranks_history` | [`Array<RanksHistory>`](../../doc/models/ranks-history.md) | Optional | - |
| `reviews` | [`Array<Review>`](../../doc/models/review.md) | Optional | - |

## Example (as JSON)

```json
{
  "title": null,
  "description": null,
  "contributor": null,
  "author": null,
  "contributor_note": null,
  "price": null,
  "age_group": null,
  "publisher": null,
  "isbns": null,
  "ranks_history": null,
  "reviews": null
}
```

