
# GET Lists Date List Json Response

## Structure

`GETListsDateListJsonResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `String` | Optional | - |
| `copyright` | `String` | Optional | - |
| `num_results` | `Integer` | Optional | - |
| `last_modified` | `String` | Optional | - |
| `results` | [`Results2`](../../doc/models/results-2.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "last_modified": null,
  "results": null
}
```

