
# Book 1

## Structure

`Book1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rank` | `Integer` | Optional | - |
| `rank_last_week` | `Integer` | Optional | - |
| `weeks_on_list` | `Integer` | Optional | - |
| `asterisk` | `Integer` | Optional | - |
| `dagger` | `Integer` | Optional | - |
| `primary_isbn_10` | `String` | Optional | - |
| `primary_isbn_13` | `String` | Optional | - |
| `publisher` | `String` | Optional | - |
| `description` | `String` | Optional | - |
| `price` | `Integer` | Optional | - |
| `title` | `String` | Optional | - |
| `author` | `String` | Optional | - |
| `contributor` | `String` | Optional | - |
| `contributor_note` | `String` | Optional | - |
| `book_image` | `String` | Optional | - |
| `amazon_product_url` | `String` | Optional | - |
| `age_group` | `String` | Optional | - |
| `book_review_link` | `String` | Optional | - |
| `first_chapter_link` | `String` | Optional | - |
| `sunday_review_link` | `String` | Optional | - |
| `article_chapter_link` | `String` | Optional | - |
| `isbns` | [`Array<Isbn>`](../../doc/models/isbn.md) | Optional | - |

## Example (as JSON)

```json
{
  "rank": null,
  "rank_last_week": null,
  "weeks_on_list": null,
  "asterisk": null,
  "dagger": null,
  "primary_isbn10": null,
  "primary_isbn13": null,
  "publisher": null,
  "description": null,
  "price": null,
  "title": null,
  "author": null,
  "contributor": null,
  "contributor_note": null,
  "book_image": null,
  "amazon_product_url": null,
  "age_group": null,
  "book_review_link": null,
  "first_chapter_link": null,
  "sunday_review_link": null,
  "article_chapter_link": null,
  "isbns": null
}
```

