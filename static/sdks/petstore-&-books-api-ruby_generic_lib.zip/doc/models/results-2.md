
# Results 2

## Structure

`Results2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `list_name` | `String` | Optional | - |
| `bestsellers_date` | `String` | Optional | - |
| `published_date` | `String` | Optional | - |
| `display_name` | `String` | Optional | - |
| `normal_list_ends_at` | `Integer` | Optional | - |
| `updated` | `String` | Optional | - |
| `books` | [`Array<Book1>`](../../doc/models/book-1.md) | Optional | - |
| `corrections` | `Array<Object>` | Optional | - |

## Example (as JSON)

```json
{
  "list_name": null,
  "bestsellers_date": null,
  "published_date": null,
  "display_name": null,
  "normal_list_ends_at": null,
  "updated": null,
  "books": null,
  "corrections": null
}
```

