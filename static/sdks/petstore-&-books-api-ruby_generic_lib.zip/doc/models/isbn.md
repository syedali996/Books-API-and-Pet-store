
# Isbn

## Structure

`Isbn`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `isbn_10` | `String` | Optional | - |
| `isbn_13` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "isbn10": null,
  "isbn13": null
}
```

