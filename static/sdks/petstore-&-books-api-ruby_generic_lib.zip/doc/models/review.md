
# Review

## Structure

`Review`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `book_review_link` | `String` | Optional | - |
| `first_chapter_link` | `String` | Optional | - |
| `sunday_review_link` | `String` | Optional | - |
| `article_chapter_link` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "book_review_link": null,
  "first_chapter_link": null,
  "sunday_review_link": null,
  "article_chapter_link": null
}
```

