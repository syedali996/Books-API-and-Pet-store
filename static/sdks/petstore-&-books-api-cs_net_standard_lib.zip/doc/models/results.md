
# Results

## Structure

`Results`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BestsellersDate` | `string` | Optional | - |
| `PublishedDate` | `string` | Optional | - |
| `Lists` | [`List<Models.List>`](../../doc/models/list.md) | Optional | - |

## Example (as JSON)

```json
{
  "bestsellers_date": null,
  "published_date": null,
  "lists": null
}
```

