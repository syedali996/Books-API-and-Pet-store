
# Isbn

## Structure

`Isbn`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Isbn10` | `string` | Optional | - |
| `Isbn13` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "isbn10": null,
  "isbn13": null
}
```

