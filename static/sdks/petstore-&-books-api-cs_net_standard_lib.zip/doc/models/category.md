
# Category

## Structure

`Category`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | - |
| `Name` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "name": null
}
```

