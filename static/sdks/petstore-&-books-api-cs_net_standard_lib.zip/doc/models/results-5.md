
# Results 5

## Structure

`Results5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Url` | `string` | Optional | - |
| `PublicationDt` | `string` | Optional | - |
| `Byline` | `string` | Optional | - |
| `BookTitle` | `string` | Optional | - |
| `BookAuthor` | `string` | Optional | - |
| `Summary` | `string` | Optional | - |
| `Isbn13` | `List<string>` | Optional | - |

## Example (as JSON)

```json
{
  "url": null,
  "publication_dt": null,
  "byline": null,
  "book_title": null,
  "book_author": null,
  "summary": null,
  "isbn13": null
}
```

