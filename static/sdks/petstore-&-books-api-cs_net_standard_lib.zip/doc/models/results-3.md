
# Results 3

## Structure

`Results3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ListName` | `string` | Optional | - |
| `DisplayName` | `string` | Optional | - |
| `ListNameEncoded` | `string` | Optional | - |
| `OldestPublishedDate` | `string` | Optional | - |
| `NewestPublishedDate` | `string` | Optional | - |
| `Updated` | [`Models.UpdatedEnum?`](../../doc/models/updated-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "list_name": null,
  "display_name": null,
  "list_name_encoded": null,
  "oldest_published_date": null,
  "newest_published_date": null,
  "updated": null
}
```

