
# Results 1

## Structure

`Results1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ListName` | `String` | Optional | - | String getListName() | setListName(String listName) |
| `DisplayName` | `String` | Optional | - | String getDisplayName() | setDisplayName(String displayName) |
| `BestsellersDate` | `String` | Optional | - | String getBestsellersDate() | setBestsellersDate(String bestsellersDate) |
| `PublishedDate` | `String` | Optional | - | String getPublishedDate() | setPublishedDate(String publishedDate) |
| `Rank` | `Integer` | Optional | - | Integer getRank() | setRank(Integer rank) |
| `RankLastWeek` | `Integer` | Optional | - | Integer getRankLastWeek() | setRankLastWeek(Integer rankLastWeek) |
| `WeeksOnList` | `Integer` | Optional | - | Integer getWeeksOnList() | setWeeksOnList(Integer weeksOnList) |
| `Asterisk` | `Integer` | Optional | - | Integer getAsterisk() | setAsterisk(Integer asterisk) |
| `Dagger` | `Integer` | Optional | - | Integer getDagger() | setDagger(Integer dagger) |
| `AmazonProductUrl` | `String` | Optional | - | String getAmazonProductUrl() | setAmazonProductUrl(String amazonProductUrl) |
| `Isbns` | [`List<Isbn>`](../../doc/models/isbn.md) | Optional | - | List<Isbn> getIsbns() | setIsbns(List<Isbn> isbns) |
| `BookDetails` | [`List<BookDetail>`](../../doc/models/book-detail.md) | Optional | - | List<BookDetail> getBookDetails() | setBookDetails(List<BookDetail> bookDetails) |
| `Reviews` | [`List<Review>`](../../doc/models/review.md) | Optional | - | List<Review> getReviews() | setReviews(List<Review> reviews) |

## Example (as JSON)

```json
{
  "list_name": null,
  "display_name": null,
  "bestsellers_date": null,
  "published_date": null,
  "rank": null,
  "rank_last_week": null,
  "weeks_on_list": null,
  "asterisk": null,
  "dagger": null,
  "amazon_product_url": null,
  "isbns": null,
  "book_details": null,
  "reviews": null
}
```

