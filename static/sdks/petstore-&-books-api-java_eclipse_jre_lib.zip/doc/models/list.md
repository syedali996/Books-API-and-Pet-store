
# List

## Structure

`List`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ListId` | `Integer` | Optional | - | Integer getListId() | setListId(Integer listId) |
| `ListName` | `String` | Optional | - | String getListName() | setListName(String listName) |
| `DisplayName` | `String` | Optional | - | String getDisplayName() | setDisplayName(String displayName) |
| `Updated` | `String` | Optional | - | String getUpdated() | setUpdated(String updated) |
| `ListImage` | `String` | Optional | - | String getListImage() | setListImage(String listImage) |
| `Books` | [`List<Book>`](../../doc/models/book.md) | Optional | - | List<Book> getBooks() | setBooks(List<Book> books) |

## Example (as JSON)

```json
{
  "list_id": null,
  "list_name": null,
  "display_name": null,
  "updated": null,
  "list_image": null,
  "books": null
}
```

