
# Status 1 Enum

Order Status

## Enumeration

`Status1Enum`

## Fields

| Name |
|  --- |
| `Placed` |
| `Approved` |
| `Delivered` |

