
# Book 1

## Structure

`Book1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Rank` | `Integer` | Optional | - | Integer getRank() | setRank(Integer rank) |
| `RankLastWeek` | `Integer` | Optional | - | Integer getRankLastWeek() | setRankLastWeek(Integer rankLastWeek) |
| `WeeksOnList` | `Integer` | Optional | - | Integer getWeeksOnList() | setWeeksOnList(Integer weeksOnList) |
| `Asterisk` | `Integer` | Optional | - | Integer getAsterisk() | setAsterisk(Integer asterisk) |
| `Dagger` | `Integer` | Optional | - | Integer getDagger() | setDagger(Integer dagger) |
| `PrimaryIsbn10` | `String` | Optional | - | String getPrimaryIsbn10() | setPrimaryIsbn10(String primaryIsbn10) |
| `PrimaryIsbn13` | `String` | Optional | - | String getPrimaryIsbn13() | setPrimaryIsbn13(String primaryIsbn13) |
| `Publisher` | `String` | Optional | - | String getPublisher() | setPublisher(String publisher) |
| `Description` | `String` | Optional | - | String getDescription() | setDescription(String description) |
| `Price` | `Integer` | Optional | - | Integer getPrice() | setPrice(Integer price) |
| `Title` | `String` | Optional | - | String getTitle() | setTitle(String title) |
| `Author` | `String` | Optional | - | String getAuthor() | setAuthor(String author) |
| `Contributor` | `String` | Optional | - | String getContributor() | setContributor(String contributor) |
| `ContributorNote` | `String` | Optional | - | String getContributorNote() | setContributorNote(String contributorNote) |
| `BookImage` | `String` | Optional | - | String getBookImage() | setBookImage(String bookImage) |
| `AmazonProductUrl` | `String` | Optional | - | String getAmazonProductUrl() | setAmazonProductUrl(String amazonProductUrl) |
| `AgeGroup` | `String` | Optional | - | String getAgeGroup() | setAgeGroup(String ageGroup) |
| `BookReviewLink` | `String` | Optional | - | String getBookReviewLink() | setBookReviewLink(String bookReviewLink) |
| `FirstChapterLink` | `String` | Optional | - | String getFirstChapterLink() | setFirstChapterLink(String firstChapterLink) |
| `SundayReviewLink` | `String` | Optional | - | String getSundayReviewLink() | setSundayReviewLink(String sundayReviewLink) |
| `ArticleChapterLink` | `String` | Optional | - | String getArticleChapterLink() | setArticleChapterLink(String articleChapterLink) |
| `Isbns` | [`List<Isbn>`](../../doc/models/isbn.md) | Optional | - | List<Isbn> getIsbns() | setIsbns(List<Isbn> isbns) |

## Example (as JSON)

```json
{
  "rank": null,
  "rank_last_week": null,
  "weeks_on_list": null,
  "asterisk": null,
  "dagger": null,
  "primary_isbn10": null,
  "primary_isbn13": null,
  "publisher": null,
  "description": null,
  "price": null,
  "title": null,
  "author": null,
  "contributor": null,
  "contributor_note": null,
  "book_image": null,
  "amazon_product_url": null,
  "age_group": null,
  "book_review_link": null,
  "first_chapter_link": null,
  "sunday_review_link": null,
  "article_chapter_link": null,
  "isbns": null
}
```

