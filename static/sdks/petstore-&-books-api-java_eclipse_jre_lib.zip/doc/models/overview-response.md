
# Overview Response

## Structure

`OverviewResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `String` | Optional | - | String getStatus() | setStatus(String status) |
| `Copyright` | `String` | Optional | - | String getCopyright() | setCopyright(String copyright) |
| `NumResults` | `Integer` | Optional | - | Integer getNumResults() | setNumResults(Integer numResults) |
| `Results` | [`Results`](../../doc/models/results.md) | Optional | - | Results getResults() | setResults(Results results) |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

