
# Isbn

## Structure

`Isbn`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Isbn10` | `String` | Optional | - | String getIsbn10() | setIsbn10(String isbn10) |
| `Isbn13` | `String` | Optional | - | String getIsbn13() | setIsbn13(String isbn13) |

## Example (as JSON)

```json
{
  "isbn10": null,
  "isbn13": null
}
```

