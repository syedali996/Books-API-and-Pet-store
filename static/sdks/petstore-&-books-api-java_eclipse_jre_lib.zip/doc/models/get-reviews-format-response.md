
# GET Reviews Format Response

## Structure

`GETReviewsFormatResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `String` | Optional | - | String getStatus() | setStatus(String status) |
| `Copyright` | `String` | Optional | - | String getCopyright() | setCopyright(String copyright) |
| `NumResults` | `Integer` | Optional | - | Integer getNumResults() | setNumResults(Integer numResults) |
| `Results` | [`List<Results5>`](../../doc/models/results-5.md) | Optional | - | List<Results5> getResults() | setResults(List<Results5> results) |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

