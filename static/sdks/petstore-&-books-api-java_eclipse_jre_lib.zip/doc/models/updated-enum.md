
# Updated Enum

## Enumeration

`UpdatedEnum`

## Fields

| Name |
|  --- |
| `WEEKLY` |
| `MONTHLY` |

