
# GET Lists Best Sellers History Json Response

## Structure

`GETListsBestSellersHistoryJsonResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `String` | Optional | - | String getStatus() | setStatus(String status) |
| `Copyright` | `String` | Optional | - | String getCopyright() | setCopyright(String copyright) |
| `NumResults` | `Integer` | Optional | - | Integer getNumResults() | setNumResults(Integer numResults) |
| `Results` | [`List<Results4>`](../../doc/models/results-4.md) | Optional | - | List<Results4> getResults() | setResults(List<Results4> results) |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

