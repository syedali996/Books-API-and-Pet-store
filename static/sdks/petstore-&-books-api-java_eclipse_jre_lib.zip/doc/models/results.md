
# Results

## Structure

`Results`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BestsellersDate` | `String` | Optional | - | String getBestsellersDate() | setBestsellersDate(String bestsellersDate) |
| `PublishedDate` | `String` | Optional | - | String getPublishedDate() | setPublishedDate(String publishedDate) |
| `Lists` | [`List<List>`](../../doc/models/list.md) | Optional | - | List<List> getLists() | setLists(List<List> lists) |

## Example (as JSON)

```json
{
  "bestsellers_date": null,
  "published_date": null,
  "lists": null
}
```

