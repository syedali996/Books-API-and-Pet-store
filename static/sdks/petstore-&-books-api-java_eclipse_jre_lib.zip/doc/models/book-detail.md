
# Book Detail

## Structure

`BookDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Title` | `String` | Optional | - | String getTitle() | setTitle(String title) |
| `Description` | `String` | Optional | - | String getDescription() | setDescription(String description) |
| `Contributor` | `String` | Optional | - | String getContributor() | setContributor(String contributor) |
| `Author` | `String` | Optional | - | String getAuthor() | setAuthor(String author) |
| `ContributorNote` | `String` | Optional | - | String getContributorNote() | setContributorNote(String contributorNote) |
| `Price` | `Integer` | Optional | - | Integer getPrice() | setPrice(Integer price) |
| `AgeGroup` | `String` | Optional | - | String getAgeGroup() | setAgeGroup(String ageGroup) |
| `Publisher` | `String` | Optional | - | String getPublisher() | setPublisher(String publisher) |
| `PrimaryIsbn13` | `String` | Optional | - | String getPrimaryIsbn13() | setPrimaryIsbn13(String primaryIsbn13) |
| `PrimaryIsbn10` | `String` | Optional | - | String getPrimaryIsbn10() | setPrimaryIsbn10(String primaryIsbn10) |

## Example (as JSON)

```json
{
  "title": null,
  "description": null,
  "contributor": null,
  "author": null,
  "contributor_note": null,
  "price": null,
  "age_group": null,
  "publisher": null,
  "primary_isbn13": null,
  "primary_isbn10": null
}
```

