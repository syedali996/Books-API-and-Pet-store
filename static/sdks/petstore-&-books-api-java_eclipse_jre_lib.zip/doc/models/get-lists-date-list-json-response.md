
# GET Lists Date List Json Response

## Structure

`GETListsDateListJsonResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `String` | Optional | - | String getStatus() | setStatus(String status) |
| `Copyright` | `String` | Optional | - | String getCopyright() | setCopyright(String copyright) |
| `NumResults` | `Integer` | Optional | - | Integer getNumResults() | setNumResults(Integer numResults) |
| `LastModified` | `String` | Optional | - | String getLastModified() | setLastModified(String lastModified) |
| `Results` | [`Results2`](../../doc/models/results-2.md) | Optional | - | Results2 getResults() | setResults(Results2 results) |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "last_modified": null,
  "results": null
}
```

