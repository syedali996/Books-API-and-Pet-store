
# GET Lists Format Response

## Structure

`GETListsFormatResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `String` | Optional | - | String getStatus() | setStatus(String status) |
| `Copyright` | `String` | Optional | - | String getCopyright() | setCopyright(String copyright) |
| `NumResults` | `Integer` | Optional | - | Integer getNumResults() | setNumResults(Integer numResults) |
| `LastModified` | `String` | Optional | - | String getLastModified() | setLastModified(String lastModified) |
| `Results` | [`List<Results1>`](../../doc/models/results-1.md) | Optional | - | List<Results1> getResults() | setResults(List<Results1> results) |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "last_modified": null,
  "results": null
}
```

