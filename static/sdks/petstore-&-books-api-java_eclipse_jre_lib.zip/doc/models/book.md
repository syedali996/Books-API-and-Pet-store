
# Book

## Structure

`Book`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AgeGroup` | `String` | Optional | - | String getAgeGroup() | setAgeGroup(String ageGroup) |
| `Author` | `String` | Optional | - | String getAuthor() | setAuthor(String author) |
| `Contributor` | `String` | Optional | - | String getContributor() | setContributor(String contributor) |
| `ContributorNote` | `String` | Optional | - | String getContributorNote() | setContributorNote(String contributorNote) |
| `CreatedDate` | `String` | Optional | - | String getCreatedDate() | setCreatedDate(String createdDate) |
| `Description` | `String` | Optional | - | String getDescription() | setDescription(String description) |
| `Price` | `Integer` | Optional | - | Integer getPrice() | setPrice(Integer price) |
| `PrimaryIsbn13` | `String` | Optional | - | String getPrimaryIsbn13() | setPrimaryIsbn13(String primaryIsbn13) |
| `PrimaryIsbn10` | `String` | Optional | - | String getPrimaryIsbn10() | setPrimaryIsbn10(String primaryIsbn10) |
| `Publisher` | `String` | Optional | - | String getPublisher() | setPublisher(String publisher) |
| `Rank` | `Integer` | Optional | - | Integer getRank() | setRank(Integer rank) |
| `Title` | `String` | Optional | - | String getTitle() | setTitle(String title) |
| `UpdatedDate` | `String` | Optional | - | String getUpdatedDate() | setUpdatedDate(String updatedDate) |

## Example (as JSON)

```json
{
  "age_group": null,
  "author": null,
  "contributor": null,
  "contributor_note": null,
  "created_date": null,
  "description": null,
  "price": null,
  "primary_isbn13": null,
  "primary_isbn10": null,
  "publisher": null,
  "rank": null,
  "title": null,
  "updated_date": null
}
```

