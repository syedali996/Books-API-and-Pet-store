
# Results 4

## Structure

`Results4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Title` | `String` | Optional | - | String getTitle() | setTitle(String title) |
| `Description` | `String` | Optional | - | String getDescription() | setDescription(String description) |
| `Contributor` | `String` | Optional | - | String getContributor() | setContributor(String contributor) |
| `Author` | `String` | Optional | - | String getAuthor() | setAuthor(String author) |
| `ContributorNote` | `String` | Optional | - | String getContributorNote() | setContributorNote(String contributorNote) |
| `Price` | `Integer` | Optional | - | Integer getPrice() | setPrice(Integer price) |
| `AgeGroup` | `String` | Optional | - | String getAgeGroup() | setAgeGroup(String ageGroup) |
| `Publisher` | `String` | Optional | - | String getPublisher() | setPublisher(String publisher) |
| `Isbns` | [`List<Isbn>`](../../doc/models/isbn.md) | Optional | - | List<Isbn> getIsbns() | setIsbns(List<Isbn> isbns) |
| `RanksHistory` | [`List<RanksHistory>`](../../doc/models/ranks-history.md) | Optional | - | List<RanksHistory> getRanksHistory() | setRanksHistory(List<RanksHistory> ranksHistory) |
| `Reviews` | [`List<Review>`](../../doc/models/review.md) | Optional | - | List<Review> getReviews() | setReviews(List<Review> reviews) |

## Example (as JSON)

```json
{
  "title": null,
  "description": null,
  "contributor": null,
  "author": null,
  "contributor_note": null,
  "price": null,
  "age_group": null,
  "publisher": null,
  "isbns": null,
  "ranks_history": null,
  "reviews": null
}
```

