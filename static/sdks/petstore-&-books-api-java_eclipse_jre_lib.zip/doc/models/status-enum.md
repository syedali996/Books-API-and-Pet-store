
# Status Enum

pet status in the store

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `Available` |
| `Pending` |
| `Sold` |

