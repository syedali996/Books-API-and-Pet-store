
# Ranks History

## Structure

`RanksHistory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PrimaryIsbn10` | `String` | Optional | - | String getPrimaryIsbn10() | setPrimaryIsbn10(String primaryIsbn10) |
| `PrimaryIsbn13` | `String` | Optional | - | String getPrimaryIsbn13() | setPrimaryIsbn13(String primaryIsbn13) |
| `Rank` | `Integer` | Optional | - | Integer getRank() | setRank(Integer rank) |
| `ListName` | `String` | Optional | - | String getListName() | setListName(String listName) |
| `DisplayName` | `String` | Optional | - | String getDisplayName() | setDisplayName(String displayName) |
| `PublishedDate` | `String` | Optional | - | String getPublishedDate() | setPublishedDate(String publishedDate) |
| `BestsellersDate` | `String` | Optional | - | String getBestsellersDate() | setBestsellersDate(String bestsellersDate) |
| `WeeksOnList` | `Integer` | Optional | - | Integer getWeeksOnList() | setWeeksOnList(Integer weeksOnList) |
| `RanksLastWeek` | `String` | Optional | - | String getRanksLastWeek() | setRanksLastWeek(String ranksLastWeek) |
| `Asterisk` | `Integer` | Optional | - | Integer getAsterisk() | setAsterisk(Integer asterisk) |
| `Dagger` | `Integer` | Optional | - | Integer getDagger() | setDagger(Integer dagger) |

## Example (as JSON)

```json
{
  "primary_isbn10": null,
  "primary_isbn13": null,
  "rank": null,
  "list_name": null,
  "display_name": null,
  "published_date": null,
  "bestsellers_date": null,
  "weeks_on_list": null,
  "ranks_last_week": null,
  "asterisk": null,
  "dagger": null
}
```

