
# GET Lists Names Format Response

## Structure

`GETListsNamesFormatResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `String` | Optional | - | String getStatus() | setStatus(String status) |
| `Copyright` | `String` | Optional | - | String getCopyright() | setCopyright(String copyright) |
| `NumResults` | `Integer` | Optional | - | Integer getNumResults() | setNumResults(Integer numResults) |
| `Results` | [`List<Results3>`](../../doc/models/results-3.md) | Optional | - | List<Results3> getResults() | setResults(List<Results3> results) |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

