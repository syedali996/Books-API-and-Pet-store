
# Review

## Structure

`Review`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BookReviewLink` | `String` | Optional | - | String getBookReviewLink() | setBookReviewLink(String bookReviewLink) |
| `FirstChapterLink` | `String` | Optional | - | String getFirstChapterLink() | setFirstChapterLink(String firstChapterLink) |
| `SundayReviewLink` | `String` | Optional | - | String getSundayReviewLink() | setSundayReviewLink(String sundayReviewLink) |
| `ArticleChapterLink` | `String` | Optional | - | String getArticleChapterLink() | setArticleChapterLink(String articleChapterLink) |

## Example (as JSON)

```json
{
  "book_review_link": null,
  "first_chapter_link": null,
  "sunday_review_link": null,
  "article_chapter_link": null
}
```

