
# Results 5

## Structure

`Results5`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Url` | `String` | Optional | - | String getUrl() | setUrl(String url) |
| `PublicationDt` | `String` | Optional | - | String getPublicationDt() | setPublicationDt(String publicationDt) |
| `Byline` | `String` | Optional | - | String getByline() | setByline(String byline) |
| `BookTitle` | `String` | Optional | - | String getBookTitle() | setBookTitle(String bookTitle) |
| `BookAuthor` | `String` | Optional | - | String getBookAuthor() | setBookAuthor(String bookAuthor) |
| `Summary` | `String` | Optional | - | String getSummary() | setSummary(String summary) |
| `Isbn13` | `List<String>` | Optional | - | List<String> getIsbn13() | setIsbn13(List<String> isbn13) |

## Example (as JSON)

```json
{
  "url": null,
  "publication_dt": null,
  "byline": null,
  "book_title": null,
  "book_author": null,
  "summary": null,
  "isbn13": null
}
```

