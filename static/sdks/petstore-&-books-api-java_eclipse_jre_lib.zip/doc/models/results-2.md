
# Results 2

## Structure

`Results2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ListName` | `String` | Optional | - | String getListName() | setListName(String listName) |
| `BestsellersDate` | `String` | Optional | - | String getBestsellersDate() | setBestsellersDate(String bestsellersDate) |
| `PublishedDate` | `String` | Optional | - | String getPublishedDate() | setPublishedDate(String publishedDate) |
| `DisplayName` | `String` | Optional | - | String getDisplayName() | setDisplayName(String displayName) |
| `NormalListEndsAt` | `Integer` | Optional | - | Integer getNormalListEndsAt() | setNormalListEndsAt(Integer normalListEndsAt) |
| `Updated` | `String` | Optional | - | String getUpdated() | setUpdated(String updated) |
| `Books` | [`List<Book1>`](../../doc/models/book-1.md) | Optional | - | List<Book1> getBooks() | setBooks(List<Book1> books) |
| `Corrections` | `List<Object>` | Optional | - | List<Object> getCorrections() | setCorrections(List<Object> corrections) |

## Example (as JSON)

```json
{
  "list_name": null,
  "bestsellers_date": null,
  "published_date": null,
  "display_name": null,
  "normal_list_ends_at": null,
  "updated": null,
  "books": null,
  "corrections": null
}
```

