
# List

## Structure

`List`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `list_id` | `int` | Optional | - |
| `list_name` | `string` | Optional | - |
| `display_name` | `string` | Optional | - |
| `updated` | `string` | Optional | - |
| `list_image` | `string` | Optional | - |
| `books` | [`List of Book`](../../doc/models/book.md) | Optional | - |

## Example (as JSON)

```json
{
  "list_id": null,
  "list_name": null,
  "display_name": null,
  "updated": null,
  "list_image": null,
  "books": null
}
```

