
# Overview Response

## Structure

`OverviewResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Optional | - |
| `copyright` | `string` | Optional | - |
| `num_results` | `int` | Optional | - |
| `results` | [`Results`](../../doc/models/results.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

