
# Results 4

## Structure

`Results4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `title` | `string` | Optional | - |
| `description` | `string` | Optional | - |
| `contributor` | `string` | Optional | - |
| `author` | `string` | Optional | - |
| `contributor_note` | `string` | Optional | - |
| `price` | `int` | Optional | - |
| `age_group` | `string` | Optional | - |
| `publisher` | `string` | Optional | - |
| `isbns` | [`List of Isbn`](../../doc/models/isbn.md) | Optional | - |
| `ranks_history` | [`List of RanksHistory`](../../doc/models/ranks-history.md) | Optional | - |
| `reviews` | [`List of Review`](../../doc/models/review.md) | Optional | - |

## Example (as JSON)

```json
{
  "title": null,
  "description": null,
  "contributor": null,
  "author": null,
  "contributor_note": null,
  "price": null,
  "age_group": null,
  "publisher": null,
  "isbns": null,
  "ranks_history": null,
  "reviews": null
}
```

