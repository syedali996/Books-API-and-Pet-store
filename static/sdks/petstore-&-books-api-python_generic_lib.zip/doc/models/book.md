
# Book

## Structure

`Book`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `age_group` | `string` | Optional | - |
| `author` | `string` | Optional | - |
| `contributor` | `string` | Optional | - |
| `contributor_note` | `string` | Optional | - |
| `created_date` | `string` | Optional | - |
| `description` | `string` | Optional | - |
| `price` | `int` | Optional | - |
| `primary_isbn_13` | `string` | Optional | - |
| `primary_isbn_10` | `string` | Optional | - |
| `publisher` | `string` | Optional | - |
| `rank` | `int` | Optional | - |
| `title` | `string` | Optional | - |
| `updated_date` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "age_group": null,
  "author": null,
  "contributor": null,
  "contributor_note": null,
  "created_date": null,
  "description": null,
  "price": null,
  "primary_isbn13": null,
  "primary_isbn10": null,
  "publisher": null,
  "rank": null,
  "title": null,
  "updated_date": null
}
```

