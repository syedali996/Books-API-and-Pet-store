
# User

## Structure

`User`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | - |
| `username` | `string` | Optional | - |
| `first_name` | `string` | Optional | - |
| `last_name` | `string` | Optional | - |
| `email` | `string` | Optional | - |
| `password` | `string` | Optional | - |
| `phone` | `string` | Optional | - |
| `user_status` | `int` | Optional | User Status |

## Example (as JSON)

```json
{
  "id": null,
  "username": null,
  "firstName": null,
  "lastName": null,
  "email": null,
  "password": null,
  "phone": null,
  "userStatus": null
}
```

