
# GET Lists Best Sellers History Json Response

## Structure

`GETListsBestSellersHistoryJsonResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Optional | - |
| `copyright` | `string` | Optional | - |
| `num_results` | `int` | Optional | - |
| `results` | [`List of Results4`](../../doc/models/results-4.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

