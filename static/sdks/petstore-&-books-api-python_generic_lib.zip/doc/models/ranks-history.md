
# Ranks History

## Structure

`RanksHistory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `primary_isbn_10` | `string` | Optional | - |
| `primary_isbn_13` | `string` | Optional | - |
| `rank` | `int` | Optional | - |
| `list_name` | `string` | Optional | - |
| `display_name` | `string` | Optional | - |
| `published_date` | `string` | Optional | - |
| `bestsellers_date` | `string` | Optional | - |
| `weeks_on_list` | `int` | Optional | - |
| `ranks_last_week` | `string` | Optional | - |
| `asterisk` | `int` | Optional | - |
| `dagger` | `int` | Optional | - |

## Example (as JSON)

```json
{
  "primary_isbn10": null,
  "primary_isbn13": null,
  "rank": null,
  "list_name": null,
  "display_name": null,
  "published_date": null,
  "bestsellers_date": null,
  "weeks_on_list": null,
  "ranks_last_week": null,
  "asterisk": null,
  "dagger": null
}
```

