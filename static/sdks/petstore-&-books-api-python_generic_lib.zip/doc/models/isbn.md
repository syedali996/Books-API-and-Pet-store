
# Isbn

## Structure

`Isbn`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `isbn_10` | `string` | Optional | - |
| `isbn_13` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "isbn10": null,
  "isbn13": null
}
```

