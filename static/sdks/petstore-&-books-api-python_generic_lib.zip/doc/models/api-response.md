
# Api Response

## Structure

`ApiResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `int` | Optional | - |
| `mtype` | `string` | Optional | - |
| `message` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "code": null,
  "type": null,
  "message": null
}
```

