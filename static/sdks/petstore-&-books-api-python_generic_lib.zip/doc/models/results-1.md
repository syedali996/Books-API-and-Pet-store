
# Results 1

## Structure

`Results1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `list_name` | `string` | Optional | - |
| `display_name` | `string` | Optional | - |
| `bestsellers_date` | `string` | Optional | - |
| `published_date` | `string` | Optional | - |
| `rank` | `int` | Optional | - |
| `rank_last_week` | `int` | Optional | - |
| `weeks_on_list` | `int` | Optional | - |
| `asterisk` | `int` | Optional | - |
| `dagger` | `int` | Optional | - |
| `amazon_product_url` | `string` | Optional | - |
| `isbns` | [`List of Isbn`](../../doc/models/isbn.md) | Optional | - |
| `book_details` | [`List of BookDetail`](../../doc/models/book-detail.md) | Optional | - |
| `reviews` | [`List of Review`](../../doc/models/review.md) | Optional | - |

## Example (as JSON)

```json
{
  "list_name": null,
  "display_name": null,
  "bestsellers_date": null,
  "published_date": null,
  "rank": null,
  "rank_last_week": null,
  "weeks_on_list": null,
  "asterisk": null,
  "dagger": null,
  "amazon_product_url": null,
  "isbns": null,
  "book_details": null,
  "reviews": null
}
```

