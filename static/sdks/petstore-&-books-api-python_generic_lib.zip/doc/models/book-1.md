
# Book 1

## Structure

`Book1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rank` | `int` | Optional | - |
| `rank_last_week` | `int` | Optional | - |
| `weeks_on_list` | `int` | Optional | - |
| `asterisk` | `int` | Optional | - |
| `dagger` | `int` | Optional | - |
| `primary_isbn_10` | `string` | Optional | - |
| `primary_isbn_13` | `string` | Optional | - |
| `publisher` | `string` | Optional | - |
| `description` | `string` | Optional | - |
| `price` | `int` | Optional | - |
| `title` | `string` | Optional | - |
| `author` | `string` | Optional | - |
| `contributor` | `string` | Optional | - |
| `contributor_note` | `string` | Optional | - |
| `book_image` | `string` | Optional | - |
| `amazon_product_url` | `string` | Optional | - |
| `age_group` | `string` | Optional | - |
| `book_review_link` | `string` | Optional | - |
| `first_chapter_link` | `string` | Optional | - |
| `sunday_review_link` | `string` | Optional | - |
| `article_chapter_link` | `string` | Optional | - |
| `isbns` | [`List of Isbn`](../../doc/models/isbn.md) | Optional | - |

## Example (as JSON)

```json
{
  "rank": null,
  "rank_last_week": null,
  "weeks_on_list": null,
  "asterisk": null,
  "dagger": null,
  "primary_isbn10": null,
  "primary_isbn13": null,
  "publisher": null,
  "description": null,
  "price": null,
  "title": null,
  "author": null,
  "contributor": null,
  "contributor_note": null,
  "book_image": null,
  "amazon_product_url": null,
  "age_group": null,
  "book_review_link": null,
  "first_chapter_link": null,
  "sunday_review_link": null,
  "article_chapter_link": null,
  "isbns": null
}
```

