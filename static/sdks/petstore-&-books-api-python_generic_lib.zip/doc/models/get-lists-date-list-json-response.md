
# GET Lists Date List Json Response

## Structure

`GETListsDateListJsonResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Optional | - |
| `copyright` | `string` | Optional | - |
| `num_results` | `int` | Optional | - |
| `last_modified` | `string` | Optional | - |
| `results` | [`Results2`](../../doc/models/results-2.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "last_modified": null,
  "results": null
}
```

