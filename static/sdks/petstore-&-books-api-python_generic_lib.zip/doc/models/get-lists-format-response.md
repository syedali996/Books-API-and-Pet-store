
# GET Lists Format Response

## Structure

`GETListsFormatResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Optional | - |
| `copyright` | `string` | Optional | - |
| `num_results` | `int` | Optional | - |
| `last_modified` | `string` | Optional | - |
| `results` | [`List of Results1`](../../doc/models/results-1.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "last_modified": null,
  "results": null
}
```

