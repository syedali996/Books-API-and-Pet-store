
# Tag

## Structure

`Tag`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | - |
| `name` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "name": null
}
```

