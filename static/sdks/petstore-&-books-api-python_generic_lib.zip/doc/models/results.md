
# Results

## Structure

`Results`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bestsellers_date` | `string` | Optional | - |
| `published_date` | `string` | Optional | - |
| `lists` | [`List of List`](../../doc/models/list.md) | Optional | - |

## Example (as JSON)

```json
{
  "bestsellers_date": null,
  "published_date": null,
  "lists": null
}
```

