
# Results 5

## Structure

`Results5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `url` | `string` | Optional | - |
| `publication_dt` | `string` | Optional | - |
| `byline` | `string` | Optional | - |
| `book_title` | `string` | Optional | - |
| `book_author` | `string` | Optional | - |
| `summary` | `string` | Optional | - |
| `isbn_13` | `List of string` | Optional | - |

## Example (as JSON)

```json
{
  "url": null,
  "publication_dt": null,
  "byline": null,
  "book_title": null,
  "book_author": null,
  "summary": null,
  "isbn13": null
}
```

