
# Results 4

## Structure

`Results4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `title` | `?string` | Optional | - | getTitle(): ?string | setTitle(?string title): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `contributor` | `?string` | Optional | - | getContributor(): ?string | setContributor(?string contributor): void |
| `author` | `?string` | Optional | - | getAuthor(): ?string | setAuthor(?string author): void |
| `contributorNote` | `?string` | Optional | - | getContributorNote(): ?string | setContributorNote(?string contributorNote): void |
| `price` | `?int` | Optional | - | getPrice(): ?int | setPrice(?int price): void |
| `ageGroup` | `?string` | Optional | - | getAgeGroup(): ?string | setAgeGroup(?string ageGroup): void |
| `publisher` | `?string` | Optional | - | getPublisher(): ?string | setPublisher(?string publisher): void |
| `isbns` | [`?(Isbn[])`](../../doc/models/isbn.md) | Optional | - | getIsbns(): ?array | setIsbns(?array isbns): void |
| `ranksHistory` | [`?(RanksHistory[])`](../../doc/models/ranks-history.md) | Optional | - | getRanksHistory(): ?array | setRanksHistory(?array ranksHistory): void |
| `reviews` | [`?(Review[])`](../../doc/models/review.md) | Optional | - | getReviews(): ?array | setReviews(?array reviews): void |

## Example (as JSON)

```json
{
  "title": null,
  "description": null,
  "contributor": null,
  "author": null,
  "contributor_note": null,
  "price": null,
  "age_group": null,
  "publisher": null,
  "isbns": null,
  "ranks_history": null,
  "reviews": null
}
```

