
# Book

## Structure

`Book`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ageGroup` | `?string` | Optional | - | getAgeGroup(): ?string | setAgeGroup(?string ageGroup): void |
| `author` | `?string` | Optional | - | getAuthor(): ?string | setAuthor(?string author): void |
| `contributor` | `?string` | Optional | - | getContributor(): ?string | setContributor(?string contributor): void |
| `contributorNote` | `?string` | Optional | - | getContributorNote(): ?string | setContributorNote(?string contributorNote): void |
| `createdDate` | `?string` | Optional | - | getCreatedDate(): ?string | setCreatedDate(?string createdDate): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `price` | `?int` | Optional | - | getPrice(): ?int | setPrice(?int price): void |
| `primaryIsbn13` | `?string` | Optional | - | getPrimaryIsbn13(): ?string | setPrimaryIsbn13(?string primaryIsbn13): void |
| `primaryIsbn10` | `?string` | Optional | - | getPrimaryIsbn10(): ?string | setPrimaryIsbn10(?string primaryIsbn10): void |
| `publisher` | `?string` | Optional | - | getPublisher(): ?string | setPublisher(?string publisher): void |
| `rank` | `?int` | Optional | - | getRank(): ?int | setRank(?int rank): void |
| `title` | `?string` | Optional | - | getTitle(): ?string | setTitle(?string title): void |
| `updatedDate` | `?string` | Optional | - | getUpdatedDate(): ?string | setUpdatedDate(?string updatedDate): void |

## Example (as JSON)

```json
{
  "age_group": null,
  "author": null,
  "contributor": null,
  "contributor_note": null,
  "created_date": null,
  "description": null,
  "price": null,
  "primary_isbn13": null,
  "primary_isbn10": null,
  "publisher": null,
  "rank": null,
  "title": null,
  "updated_date": null
}
```

