
# Overview Response

## Structure

`OverviewResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | `?string` | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `copyright` | `?string` | Optional | - | getCopyright(): ?string | setCopyright(?string copyright): void |
| `numResults` | `?int` | Optional | - | getNumResults(): ?int | setNumResults(?int numResults): void |
| `results` | [`?Results`](../../doc/models/results.md) | Optional | - | getResults(): ?Results | setResults(?Results results): void |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

