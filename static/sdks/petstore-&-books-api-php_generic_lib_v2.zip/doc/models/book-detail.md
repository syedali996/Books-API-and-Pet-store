
# Book Detail

## Structure

`BookDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `title` | `?string` | Optional | - | getTitle(): ?string | setTitle(?string title): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `contributor` | `?string` | Optional | - | getContributor(): ?string | setContributor(?string contributor): void |
| `author` | `?string` | Optional | - | getAuthor(): ?string | setAuthor(?string author): void |
| `contributorNote` | `?string` | Optional | - | getContributorNote(): ?string | setContributorNote(?string contributorNote): void |
| `price` | `?int` | Optional | - | getPrice(): ?int | setPrice(?int price): void |
| `ageGroup` | `?string` | Optional | - | getAgeGroup(): ?string | setAgeGroup(?string ageGroup): void |
| `publisher` | `?string` | Optional | - | getPublisher(): ?string | setPublisher(?string publisher): void |
| `primaryIsbn13` | `?string` | Optional | - | getPrimaryIsbn13(): ?string | setPrimaryIsbn13(?string primaryIsbn13): void |
| `primaryIsbn10` | `?string` | Optional | - | getPrimaryIsbn10(): ?string | setPrimaryIsbn10(?string primaryIsbn10): void |

## Example (as JSON)

```json
{
  "title": null,
  "description": null,
  "contributor": null,
  "author": null,
  "contributor_note": null,
  "price": null,
  "age_group": null,
  "publisher": null,
  "primary_isbn13": null,
  "primary_isbn10": null
}
```

