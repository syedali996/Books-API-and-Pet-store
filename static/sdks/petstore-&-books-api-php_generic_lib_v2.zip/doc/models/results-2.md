
# Results 2

## Structure

`Results2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `listName` | `?string` | Optional | - | getListName(): ?string | setListName(?string listName): void |
| `bestsellersDate` | `?string` | Optional | - | getBestsellersDate(): ?string | setBestsellersDate(?string bestsellersDate): void |
| `publishedDate` | `?string` | Optional | - | getPublishedDate(): ?string | setPublishedDate(?string publishedDate): void |
| `displayName` | `?string` | Optional | - | getDisplayName(): ?string | setDisplayName(?string displayName): void |
| `normalListEndsAt` | `?int` | Optional | - | getNormalListEndsAt(): ?int | setNormalListEndsAt(?int normalListEndsAt): void |
| `updated` | `?string` | Optional | - | getUpdated(): ?string | setUpdated(?string updated): void |
| `books` | [`?(Book1[])`](../../doc/models/book-1.md) | Optional | - | getBooks(): ?array | setBooks(?array books): void |
| `corrections` | `?(array[])` | Optional | - | getCorrections(): ?array | setCorrections(?array corrections): void |

## Example (as JSON)

```json
{
  "list_name": null,
  "bestsellers_date": null,
  "published_date": null,
  "display_name": null,
  "normal_list_ends_at": null,
  "updated": null,
  "books": null,
  "corrections": null
}
```

