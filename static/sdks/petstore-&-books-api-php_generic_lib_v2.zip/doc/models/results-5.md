
# Results 5

## Structure

`Results5`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `url` | `?string` | Optional | - | getUrl(): ?string | setUrl(?string url): void |
| `publicationDt` | `?string` | Optional | - | getPublicationDt(): ?string | setPublicationDt(?string publicationDt): void |
| `byline` | `?string` | Optional | - | getByline(): ?string | setByline(?string byline): void |
| `bookTitle` | `?string` | Optional | - | getBookTitle(): ?string | setBookTitle(?string bookTitle): void |
| `bookAuthor` | `?string` | Optional | - | getBookAuthor(): ?string | setBookAuthor(?string bookAuthor): void |
| `summary` | `?string` | Optional | - | getSummary(): ?string | setSummary(?string summary): void |
| `isbn13` | `?(string[])` | Optional | - | getIsbn13(): ?array | setIsbn13(?array isbn13): void |

## Example (as JSON)

```json
{
  "url": null,
  "publication_dt": null,
  "byline": null,
  "book_title": null,
  "book_author": null,
  "summary": null,
  "isbn13": null
}
```

