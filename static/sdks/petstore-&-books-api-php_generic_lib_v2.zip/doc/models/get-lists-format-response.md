
# GET Lists Format Response

## Structure

`GETListsFormatResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | `?string` | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `copyright` | `?string` | Optional | - | getCopyright(): ?string | setCopyright(?string copyright): void |
| `numResults` | `?int` | Optional | - | getNumResults(): ?int | setNumResults(?int numResults): void |
| `lastModified` | `?string` | Optional | - | getLastModified(): ?string | setLastModified(?string lastModified): void |
| `results` | [`?(Results1[])`](../../doc/models/results-1.md) | Optional | - | getResults(): ?array | setResults(?array results): void |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "last_modified": null,
  "results": null
}
```

