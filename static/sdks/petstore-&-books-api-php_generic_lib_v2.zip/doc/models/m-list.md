
# M List

## Structure

`MList`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `listId` | `?int` | Optional | - | getListId(): ?int | setListId(?int listId): void |
| `listName` | `?string` | Optional | - | getListName(): ?string | setListName(?string listName): void |
| `displayName` | `?string` | Optional | - | getDisplayName(): ?string | setDisplayName(?string displayName): void |
| `updated` | `?string` | Optional | - | getUpdated(): ?string | setUpdated(?string updated): void |
| `listImage` | `?string` | Optional | - | getListImage(): ?string | setListImage(?string listImage): void |
| `books` | [`?(Book[])`](../../doc/models/book.md) | Optional | - | getBooks(): ?array | setBooks(?array books): void |

## Example (as JSON)

```json
{
  "list_id": null,
  "list_name": null,
  "display_name": null,
  "updated": null,
  "list_image": null,
  "books": null
}
```

