
# Ranks History

## Structure

`RanksHistory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `primaryIsbn10` | `?string` | Optional | - | getPrimaryIsbn10(): ?string | setPrimaryIsbn10(?string primaryIsbn10): void |
| `primaryIsbn13` | `?string` | Optional | - | getPrimaryIsbn13(): ?string | setPrimaryIsbn13(?string primaryIsbn13): void |
| `rank` | `?int` | Optional | - | getRank(): ?int | setRank(?int rank): void |
| `listName` | `?string` | Optional | - | getListName(): ?string | setListName(?string listName): void |
| `displayName` | `?string` | Optional | - | getDisplayName(): ?string | setDisplayName(?string displayName): void |
| `publishedDate` | `?string` | Optional | - | getPublishedDate(): ?string | setPublishedDate(?string publishedDate): void |
| `bestsellersDate` | `?string` | Optional | - | getBestsellersDate(): ?string | setBestsellersDate(?string bestsellersDate): void |
| `weeksOnList` | `?int` | Optional | - | getWeeksOnList(): ?int | setWeeksOnList(?int weeksOnList): void |
| `ranksLastWeek` | `?string` | Optional | - | getRanksLastWeek(): ?string | setRanksLastWeek(?string ranksLastWeek): void |
| `asterisk` | `?int` | Optional | - | getAsterisk(): ?int | setAsterisk(?int asterisk): void |
| `dagger` | `?int` | Optional | - | getDagger(): ?int | setDagger(?int dagger): void |

## Example (as JSON)

```json
{
  "primary_isbn10": null,
  "primary_isbn13": null,
  "rank": null,
  "list_name": null,
  "display_name": null,
  "published_date": null,
  "bestsellers_date": null,
  "weeks_on_list": null,
  "ranks_last_week": null,
  "asterisk": null,
  "dagger": null
}
```

