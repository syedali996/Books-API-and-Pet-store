
# Review

## Structure

`Review`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `bookReviewLink` | `?string` | Optional | - | getBookReviewLink(): ?string | setBookReviewLink(?string bookReviewLink): void |
| `firstChapterLink` | `?string` | Optional | - | getFirstChapterLink(): ?string | setFirstChapterLink(?string firstChapterLink): void |
| `sundayReviewLink` | `?string` | Optional | - | getSundayReviewLink(): ?string | setSundayReviewLink(?string sundayReviewLink): void |
| `articleChapterLink` | `?string` | Optional | - | getArticleChapterLink(): ?string | setArticleChapterLink(?string articleChapterLink): void |

## Example (as JSON)

```json
{
  "book_review_link": null,
  "first_chapter_link": null,
  "sunday_review_link": null,
  "article_chapter_link": null
}
```

