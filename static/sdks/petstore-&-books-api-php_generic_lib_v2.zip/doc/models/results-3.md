
# Results 3

## Structure

`Results3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `listName` | `?string` | Optional | - | getListName(): ?string | setListName(?string listName): void |
| `displayName` | `?string` | Optional | - | getDisplayName(): ?string | setDisplayName(?string displayName): void |
| `listNameEncoded` | `?string` | Optional | - | getListNameEncoded(): ?string | setListNameEncoded(?string listNameEncoded): void |
| `oldestPublishedDate` | `?string` | Optional | - | getOldestPublishedDate(): ?string | setOldestPublishedDate(?string oldestPublishedDate): void |
| `newestPublishedDate` | `?string` | Optional | - | getNewestPublishedDate(): ?string | setNewestPublishedDate(?string newestPublishedDate): void |
| `updated` | [`?string (UpdatedEnum)`](../../doc/models/updated-enum.md) | Optional | - | getUpdated(): ?string | setUpdated(?string updated): void |

## Example (as JSON)

```json
{
  "list_name": null,
  "display_name": null,
  "list_name_encoded": null,
  "oldest_published_date": null,
  "newest_published_date": null,
  "updated": null
}
```

