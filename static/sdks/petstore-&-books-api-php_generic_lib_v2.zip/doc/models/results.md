
# Results

## Structure

`Results`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `bestsellersDate` | `?string` | Optional | - | getBestsellersDate(): ?string | setBestsellersDate(?string bestsellersDate): void |
| `publishedDate` | `?string` | Optional | - | getPublishedDate(): ?string | setPublishedDate(?string publishedDate): void |
| `lists` | [`?(MList[])`](../../doc/models/m-list.md) | Optional | - | getLists(): ?array | setLists(?array lists): void |

## Example (as JSON)

```json
{
  "bestsellers_date": null,
  "published_date": null,
  "lists": null
}
```

