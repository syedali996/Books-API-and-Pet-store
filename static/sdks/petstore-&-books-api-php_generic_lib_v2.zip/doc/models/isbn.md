
# Isbn

## Structure

`Isbn`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `isbn10` | `?string` | Optional | - | getIsbn10(): ?string | setIsbn10(?string isbn10): void |
| `isbn13` | `?string` | Optional | - | getIsbn13(): ?string | setIsbn13(?string isbn13): void |

## Example (as JSON)

```json
{
  "isbn10": null,
  "isbn13": null
}
```

