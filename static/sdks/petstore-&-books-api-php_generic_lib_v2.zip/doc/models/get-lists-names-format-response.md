
# GET Lists Names Format Response

## Structure

`GETListsNamesFormatResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | `?string` | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `copyright` | `?string` | Optional | - | getCopyright(): ?string | setCopyright(?string copyright): void |
| `numResults` | `?int` | Optional | - | getNumResults(): ?int | setNumResults(?int numResults): void |
| `results` | [`?(Results3[])`](../../doc/models/results-3.md) | Optional | - | getResults(): ?array | setResults(?array results): void |

## Example (as JSON)

```json
{
  "status": null,
  "copyright": null,
  "num_results": null,
  "results": null
}
```

