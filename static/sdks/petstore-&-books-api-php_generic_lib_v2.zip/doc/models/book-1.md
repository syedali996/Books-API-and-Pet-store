
# Book 1

## Structure

`Book1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `rank` | `?int` | Optional | - | getRank(): ?int | setRank(?int rank): void |
| `rankLastWeek` | `?int` | Optional | - | getRankLastWeek(): ?int | setRankLastWeek(?int rankLastWeek): void |
| `weeksOnList` | `?int` | Optional | - | getWeeksOnList(): ?int | setWeeksOnList(?int weeksOnList): void |
| `asterisk` | `?int` | Optional | - | getAsterisk(): ?int | setAsterisk(?int asterisk): void |
| `dagger` | `?int` | Optional | - | getDagger(): ?int | setDagger(?int dagger): void |
| `primaryIsbn10` | `?string` | Optional | - | getPrimaryIsbn10(): ?string | setPrimaryIsbn10(?string primaryIsbn10): void |
| `primaryIsbn13` | `?string` | Optional | - | getPrimaryIsbn13(): ?string | setPrimaryIsbn13(?string primaryIsbn13): void |
| `publisher` | `?string` | Optional | - | getPublisher(): ?string | setPublisher(?string publisher): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `price` | `?int` | Optional | - | getPrice(): ?int | setPrice(?int price): void |
| `title` | `?string` | Optional | - | getTitle(): ?string | setTitle(?string title): void |
| `author` | `?string` | Optional | - | getAuthor(): ?string | setAuthor(?string author): void |
| `contributor` | `?string` | Optional | - | getContributor(): ?string | setContributor(?string contributor): void |
| `contributorNote` | `?string` | Optional | - | getContributorNote(): ?string | setContributorNote(?string contributorNote): void |
| `bookImage` | `?string` | Optional | - | getBookImage(): ?string | setBookImage(?string bookImage): void |
| `amazonProductUrl` | `?string` | Optional | - | getAmazonProductUrl(): ?string | setAmazonProductUrl(?string amazonProductUrl): void |
| `ageGroup` | `?string` | Optional | - | getAgeGroup(): ?string | setAgeGroup(?string ageGroup): void |
| `bookReviewLink` | `?string` | Optional | - | getBookReviewLink(): ?string | setBookReviewLink(?string bookReviewLink): void |
| `firstChapterLink` | `?string` | Optional | - | getFirstChapterLink(): ?string | setFirstChapterLink(?string firstChapterLink): void |
| `sundayReviewLink` | `?string` | Optional | - | getSundayReviewLink(): ?string | setSundayReviewLink(?string sundayReviewLink): void |
| `articleChapterLink` | `?string` | Optional | - | getArticleChapterLink(): ?string | setArticleChapterLink(?string articleChapterLink): void |
| `isbns` | [`?(Isbn[])`](../../doc/models/isbn.md) | Optional | - | getIsbns(): ?array | setIsbns(?array isbns): void |

## Example (as JSON)

```json
{
  "rank": null,
  "rank_last_week": null,
  "weeks_on_list": null,
  "asterisk": null,
  "dagger": null,
  "primary_isbn10": null,
  "primary_isbn13": null,
  "publisher": null,
  "description": null,
  "price": null,
  "title": null,
  "author": null,
  "contributor": null,
  "contributor_note": null,
  "book_image": null,
  "amazon_product_url": null,
  "age_group": null,
  "book_review_link": null,
  "first_chapter_link": null,
  "sunday_review_link": null,
  "article_chapter_link": null,
  "isbns": null
}
```

