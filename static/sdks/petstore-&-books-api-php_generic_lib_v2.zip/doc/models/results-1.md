
# Results 1

## Structure

`Results1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `listName` | `?string` | Optional | - | getListName(): ?string | setListName(?string listName): void |
| `displayName` | `?string` | Optional | - | getDisplayName(): ?string | setDisplayName(?string displayName): void |
| `bestsellersDate` | `?string` | Optional | - | getBestsellersDate(): ?string | setBestsellersDate(?string bestsellersDate): void |
| `publishedDate` | `?string` | Optional | - | getPublishedDate(): ?string | setPublishedDate(?string publishedDate): void |
| `rank` | `?int` | Optional | - | getRank(): ?int | setRank(?int rank): void |
| `rankLastWeek` | `?int` | Optional | - | getRankLastWeek(): ?int | setRankLastWeek(?int rankLastWeek): void |
| `weeksOnList` | `?int` | Optional | - | getWeeksOnList(): ?int | setWeeksOnList(?int weeksOnList): void |
| `asterisk` | `?int` | Optional | - | getAsterisk(): ?int | setAsterisk(?int asterisk): void |
| `dagger` | `?int` | Optional | - | getDagger(): ?int | setDagger(?int dagger): void |
| `amazonProductUrl` | `?string` | Optional | - | getAmazonProductUrl(): ?string | setAmazonProductUrl(?string amazonProductUrl): void |
| `isbns` | [`?(Isbn[])`](../../doc/models/isbn.md) | Optional | - | getIsbns(): ?array | setIsbns(?array isbns): void |
| `bookDetails` | [`?(BookDetail[])`](../../doc/models/book-detail.md) | Optional | - | getBookDetails(): ?array | setBookDetails(?array bookDetails): void |
| `reviews` | [`?(Review[])`](../../doc/models/review.md) | Optional | - | getReviews(): ?array | setReviews(?array reviews): void |

## Example (as JSON)

```json
{
  "list_name": null,
  "display_name": null,
  "bestsellers_date": null,
  "published_date": null,
  "rank": null,
  "rank_last_week": null,
  "weeks_on_list": null,
  "asterisk": null,
  "dagger": null,
  "amazon_product_url": null,
  "isbns": null,
  "book_details": null,
  "reviews": null
}
```

